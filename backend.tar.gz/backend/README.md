# Tripleten web_project_around_express

# Proyecto 16 (antes 15)

#Este proyecto implementa un servidor Node Express en el puerto 3000

# Se conecta a una base de datos MongoDB. Se usan también las tecnologías

# Express, Postman, Mongoose y REST.
